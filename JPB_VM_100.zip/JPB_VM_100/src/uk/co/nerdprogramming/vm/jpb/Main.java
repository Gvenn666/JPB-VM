package uk.co.nerdprogramming.vm.jpb;

public class Main {
	static String[] source = {
			"LDI A #90",
			"ADD A B"
	};
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Processor p = new Processor();
		Integer[] bin = p.assemble(source);
		
		for(Integer I : bin) System.out.println(I);
	}

}
