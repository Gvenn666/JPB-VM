package uk.co.nerdprogramming.vm.jpb;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Language {
	HashMap<String, Integer> langTable;
	public Language(String path) {
		try {
			langTable = new HashMap<String, Integer>();
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line;
			while((line = br.readLine()) != null) {
				String[] toks = line.split(":");
				langTable.put(toks[0], Integer.parseInt(toks[1],16));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("Unable To Build Language File...");
			e.printStackTrace();
		}
		
	}
	
	public int lookUp(String key) {
		if((langTable == null) || (!langTable.containsKey(key))) {
			return -1;
		}
		
		return langTable.get(key);
	}
	
	public boolean contains(String key) {
		return langTable.containsKey(key);
	}
}
