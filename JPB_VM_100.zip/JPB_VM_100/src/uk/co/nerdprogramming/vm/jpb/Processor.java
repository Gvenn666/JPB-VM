package uk.co.nerdprogramming.vm.jpb;

import java.util.ArrayList;

public class Processor {
	
	Language jpb = new Language("/home/herring/Desktop/JPB.lang");
	
	public Integer[] assemble(String[] source) {
		ArrayList<Integer> bin = new ArrayList<Integer>();
		
		for(String line : source) {
			String[] toks = line.split(" ");
			for(String t : toks) {
				if(jpb.contains(t)) {bin.add(jpb.lookUp(t));}
				else {bin.add(parseNum(t));}
			}
		}
		
		return bin.toArray(new Integer[bin.size()]);
	}
	
	@SuppressWarnings("finally")
	public int parseNum(String s) {
		
		if(s.length() <= 1) {return -1;}
		
		int dat = 0;
		char type = s.charAt(0);
		String val = s.substring(1);
		
		
		try {
			

			switch(type) {
			
			case '#': dat = Integer.parseInt(val); break;
			case '%': dat = Integer.parseInt(val,2); break;
			case '$': dat = Integer.parseInt(val,16); break;
			case '\'': dat = val.codePointAt(0); break;
			
			}
		} catch (NumberFormatException nfex) {
			
			dat = parseNum(s);
			
		} catch (StackOverflowError soex) {
			System.err.println("Unknown Token: "+s);
		} finally {
			return dat;
		}
	}
	
	

}
