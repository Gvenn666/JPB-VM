package uk.co.nerdprogramming.vm.jpb.asm;
import java.util.*;
public class VariableStore {
	HashMap<String, Integer> store = new HashMap<String, Integer>();
	int count = 0;
	public void add(String label, int value) {
		store.put(label, value);
	}
	
	public void add(String label) {
		store.put(label, count++);
	}
	
	public int lookUp(String key) {
		if(store.containsKey(key)) return store.get(key);
		return 0;
	}
}
