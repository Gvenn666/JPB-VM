package uk.co.nerdprogramming.vm.jpb.asm;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
	static String[] source = {
			"LDI A #90",
			"ADD A B"
	};
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Processor p = new Processor();
		source = loadStrings(args[0]);
		Integer[] bin = p.assemble(source);
		
		for(Integer I : bin) System.out.println(I);
		
		saveInts(bin,args[1]);
	}
	
	static String[] loadStrings(String path) {
		ArrayList<String> buff = new ArrayList<String>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line;
			while((line = br.readLine()) != null) {
				buff.add(line);
			}
			return buff.toArray(new String[buff.size()]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
		return null;
	}
	
	static void saveInts(Integer[] ints, String path) {
		try {
			DataOutputStream dos = new DataOutputStream(new FileOutputStream(path));
			for(Integer I : ints) dos.writeInt(I.intValue()); 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
