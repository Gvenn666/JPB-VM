module jpb_vm_100 {
}